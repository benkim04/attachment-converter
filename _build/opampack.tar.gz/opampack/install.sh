#!/bin/bash
export OPAMROOT=$PWD/opamroot
eval $(./opam env --root=$PWD/opamroot)
./opam install -y --assume-depexts  ocaml.4.14.2 ocamlbuild dune.3.16.0 ocamlfind mrmime ocamlnet camlp-streams ounit2 cmdliner utop ocamlformat-rpc ocaml-lsp-server prelude
