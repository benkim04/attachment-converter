module Console = Dune_console
include Dune_config
