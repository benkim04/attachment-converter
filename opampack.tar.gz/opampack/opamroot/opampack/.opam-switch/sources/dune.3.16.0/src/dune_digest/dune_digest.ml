module Digest = Digest
module Clflags = Clflags
module Cached_digest = Cached_digest
include Digest
