type ('hit, 'miss) t =
  | Hit of 'hit
  | Miss of 'miss
