include Memo.Make_parallel_map (Package.Name.Map)
