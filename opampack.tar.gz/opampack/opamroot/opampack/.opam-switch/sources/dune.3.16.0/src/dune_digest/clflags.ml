let wait_for_filesystem_clock = ref false
let debug_digests = ref false
