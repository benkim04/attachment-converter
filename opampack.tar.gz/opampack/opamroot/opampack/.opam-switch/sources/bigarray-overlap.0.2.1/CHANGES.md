### v0.2.1 2020-04-08 Paris (France)

- Remove `bigarray-compat`, revise C compilation for MirageOS 3,
  remove the Xen support (merged into Solo5),
  and support only OCaml >= 4.08 (@hannesm, #3)

### v0.2.0 2020-05-07 Paris (France)

- Support of `js_of_ocaml`
- Better layout to support MirageOS 3
- `conf-pkg-config` as a _depopt_

### v0.1.0 2020-03-12 Paris (France)

- First release
