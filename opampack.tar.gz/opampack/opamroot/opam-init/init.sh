if [ -t 0 ]; then
  test -r /Users/benjaminkim/attachment-converter/attachment-converter/opampack/opamroot/opam-init/complete.sh && . /Users/benjaminkim/attachment-converter/attachment-converter/opampack/opamroot/opam-init/complete.sh > /dev/null 2> /dev/null || true

  test -r /Users/benjaminkim/attachment-converter/attachment-converter/opampack/opamroot/opam-init/env_hook.sh && . /Users/benjaminkim/attachment-converter/attachment-converter/opampack/opamroot/opam-init/env_hook.sh > /dev/null 2> /dev/null || true
fi

test -r /Users/benjaminkim/attachment-converter/attachment-converter/opampack/opamroot/opam-init/variables.sh && . /Users/benjaminkim/attachment-converter/attachment-converter/opampack/opamroot/opam-init/variables.sh > /dev/null 2> /dev/null || true
