if [[ -o interactive ]]; then
  [[ ! -r /Users/benjaminkim/attachment-converter/attachment-converter/opampack/opamroot/opam-init/complete.zsh ]] || source /Users/benjaminkim/attachment-converter/attachment-converter/opampack/opamroot/opam-init/complete.zsh  > /dev/null 2> /dev/null

  [[ ! -r /Users/benjaminkim/attachment-converter/attachment-converter/opampack/opamroot/opam-init/env_hook.zsh ]] || source /Users/benjaminkim/attachment-converter/attachment-converter/opampack/opamroot/opam-init/env_hook.zsh  > /dev/null 2> /dev/null
fi

[[ ! -r /Users/benjaminkim/attachment-converter/attachment-converter/opampack/opamroot/opam-init/variables.sh ]] || source /Users/benjaminkim/attachment-converter/attachment-converter/opampack/opamroot/opam-init/variables.sh  > /dev/null 2> /dev/null
